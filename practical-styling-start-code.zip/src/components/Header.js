function Header() {
    return (
        <header className="header">
            <h1>Header content here</h1>
        </header>
    )
}

export default Header;