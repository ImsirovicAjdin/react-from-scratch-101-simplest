# About this React app

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

This project is [deployed on Netlify](https://roaring-stardust-1ca4f1.netlify.app/).

## Tasks

1. Simplify the starter create-react-app
2. Deploy the simplified app to Netlify
